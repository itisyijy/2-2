public class StockPurchase {
	private int cost;
	public StockPurchase(int price) {
		cost = price;
	}
	public int getCostPerShare() {
		return cost;
	}
}
